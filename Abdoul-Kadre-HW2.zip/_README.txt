In this homework I created two programs: Coordinator and Checker.

The Coordinator is responsible for launching 4 processes that it will load with the Checker program.

Checker: This program requires two arguments to complete its task. The Checker checks whether or not argTwo (the dividend) is divisible by argOne (the divisor) and prints out the result. Both these arguments are
positive integers.
